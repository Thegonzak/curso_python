def suma(num_1: int, num_2: int):
    result = num_1 + num_2
    print(f"la suma es:{result}")


def resta(num_1: int, num_2: int):
    result = num_1 - num_2
    print(f"la resta es:{result}")
