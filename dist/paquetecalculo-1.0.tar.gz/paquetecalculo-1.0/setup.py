from setuptools import setup

setup(
    name="paquetecalculo",
    version="1.0",
    description="Operaciones Matematicas",
    author="GonzaloSaucedo",
    packages=["calculos", "calculos.basicos"]
)
